Atom package for LIL
====================

   This directory contains a package for the Atom text editor which adds
   syntax highlighting support for LIL files.  To install this, just copy or
   symlink the language-lil file in the Atom's Packages directory (f.e. for
   Linux that would be ~/.atom/packages).

   Note that the syntax isn't precise, it was made quickly by stitching
   together snippets from other grammar files and trial-and-error using a
   couple of my own LIL scripts.  It should work for most scripts though,
   but do not use it as a test for syntax-correctness.

