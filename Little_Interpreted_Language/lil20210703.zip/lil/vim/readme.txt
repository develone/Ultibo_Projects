vimfile for lil
===============

   This directory contains a vimfile for lil syntax highlighting. It is
   required both for plain lil files (*.lil) and for extended lil files for
   other projects (such as lilart's *.lilart and *.ladoc).
 
   To install this file in your vim installation put it in your syntax syntax
   directory under ~/.vim (or wherever the vim configuration directory is).
   See :help new-filetype for instructions on how to make vim automatically set
   the filetype for *.ladoc and *.lilart files to ladoc and lilart.  Personally
   i use the "C" method described in the new-filetype help section.


